#pragma once
 
enum VertexComp
{
	IDENTICAL,
	SAME_POSITION,
	DIFFERENT
};
